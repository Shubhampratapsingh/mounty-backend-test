<?php
include('db.php');
mysqli_query($conn,"DELETE FROM mounty where pid='" .$_GET["pid"]."'");
echo "Data deleted successfully";
?>