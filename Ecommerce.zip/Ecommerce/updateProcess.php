<?php
include('db.php');
if(count($_POST)>0) {
mysqli_query($conn,"UPDATE mounty set pid='" . $_POST['pid'] . "', 
													title='" . $_POST['title'] . "', 
													des='" . $_POST['des'] . "',
												    cp='" . $_POST['cp'] . "' ,
												    sp='" . $_POST['sp'] . "' ,
												    img='" . $_POST['img'] . "' 
												    WHERE pid='" . $_POST['pid'] . "'");

$message = "Record Modified Successfully";
}
$result = mysqli_query($conn,"SELECT * FROM mounty WHERE pid='" . $_GET['pid'] . "'");
$row= mysqli_fetch_array($result);
?>
<html>
<head>
<title>Update  Data</title>
<h1 style="color: blue;">Update Product</h1>
<style>
		body{
			font-family: Times New Roman;
			font-size: 20px;
			color: green;
			margin:30px;
			padding: 20px;
		}
	</style>
</head>
<body>
<form name="frmUser" method="post" action="">
<div><?php 
	if(isset($message)) 
		{
		 echo $message; 
		} 
		?>
</div>
<div style="padding-bottom:5px;">
<a href="retrieve.php">List</a>
</div>
Product Name: <br>
<input type="hidden" name="pid" class="txtField" value="<?php echo $row['pid']; ?>">
<input type="text" name="pid"  value="<?php echo $row['pid']; ?>">
<br>
Title: <br>
<input type="text" name="title" class="txtField" value="<?php echo $row['title']; ?>">
<br>
Description :<br>
<input type="text" name="des" class="txtField" value="<?php echo $row['des']; ?>">
<br>
Cost Price:<br>
<input type="number" name="cp" class="txtField" value="<?php echo $row['cp']; ?>">
<br>
Selling Price:<br>
<input type="number" name="sp" class="txtField" value="<?php echo $row['sp']; ?>">
<br>
Product Image:<br>
<input type="file" name="img" class="txtField" value="<?php echo $row['img']; ?>">
<br>
<input type="submit" name="submit" value="Submit" class="buttom">

</form>
</body>
</html>