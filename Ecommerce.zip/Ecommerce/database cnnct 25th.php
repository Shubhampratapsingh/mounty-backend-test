<?php
$dbHost='localhost';
$dbUser='shubham';
$dbpwd='shubham';
$dbDbs='new table';

$conn=mysqli_connect($dbHost,$dbUser,$dbpwd,$dbDbs);