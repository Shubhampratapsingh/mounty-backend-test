<?php
include('db.php');
$result=mysqli_query($conn,"SELECT * FROM mounty");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Retrieve Data</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
	</head>
<body>
<table>
	<tr>
		<td>Product Name</td>
		<td>Product Description</td>
		<td>Cost Price</td>
		<td>Selling Price</td>
		<td>Product Image</td>
	</tr>
	<?php
	 $i=0;
	 while ($row=mysqli_fetch_array($result)) {
	 	if($i%2==0)
	 		$classname="even";
	 	else
	 		$classname="odd";


	  ?>

	  <tr class="<?php if(isset($classname)) echo $classname;?>">
	  	<td><?php echo $row["title"]; ?></td>
	  	<td><?php echo $row["des"]; ?></td>
	  	<td><?php echo $row["cp"]; ?></td>
	  	<td><?php echo $row["sp"]; ?></td>
	  	<td> <img src="images/<?php echo $row["img"]; ?>"width='150' height='100' />
		</td>
	  	</tr>
	  <?php
	  $i++;
	}
	?>
</table>
</body>
</html>