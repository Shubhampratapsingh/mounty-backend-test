<?php
include 'shop db.php';
$result=mysqli_query($conn,"SELECT * FROM shop");
	if(isset($_POST['submit']))
	{
	$Uname = mysqli_real_escape_string($conn,check($_POST['user']));//check($_POST['user']);
	$Pwd = mysqli_real_escape_string($conn,check($_POST['pwd']));
	$Cpwd = mysqli_real_escape_string($conn,check($_POST['cpwd']));
	$email = mysqli_real_escape_string($conn,check($_POST['Email']));
	$Phone = mysqli_real_escape_string($conn,check($_POST['phone']));


	$hashedpwd=password_hash($Pwd,PASSWORD_DEFAULT);
	
	if(empty($Uname) || empty($Pwd) || empty($Cpwd) || empty($email) || empty($Phone))
	{
		header("location:shopProcess.php?error=All fields are required");
	}
	else{
		if($Cpwd != $Pwd)
		{
			header("location:shopProcess?error=Passwords Do not Match");
		}
		else
		{
			if(!filter_var($email,FILTER_VALIDATE_EMAIL))
			{
				header("location:shopProcess.php?error=Email Not Valid");
			}

		else{
			$sql1 = "SELECT * FROM shop WHERE Email = '$email';";
			$result = mysqli_query($conn,$sql1);
			$resultcheck = mysqli_num_rows($result);
			if($resultcheck > 0)
			{
				header("location:shopProcess.php?error=Email Already Registered");
			}
			else{
					if (!preg_match("/^[a-z0-9]{1}[a-z0-9]{3,10}[a-z0-9]{1}$/i",$Uname)) 
					{
						header("location:shopProcess.php?error=Username not valid");
					}

			else{
				$sql = "INSERT INTO shop (Uname,Pass,Email,Phone) VALUES ('$Uname','$hashedpwd','$email','$Phone')";
			mysqli_query($conn,$sql);
			header("location:shopProcess.php?error= Successfully added to cart and your order id is");
		}
	}


			}
			
			
		}}}
	function check($data)
	{
		$data=trim($data);
		$data=htmlspecialchars($data);
		$data=stripcslashes($data);
		return $data;
	}
	?>