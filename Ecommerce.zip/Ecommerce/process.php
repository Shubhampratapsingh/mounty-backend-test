<?php
include('db.php');
if(isset($_POST['save']))
{
	$title=$_POST['title'];
	$des=$_POST['des'];
	$cp=$_POST['cp'];
	$sp=$_POST['sp'];
	$img=$_POST['img'];

	mysqli_query($conn,"INSERT INTO mounty(title,des,cp,sp,img) values('$title','$des','$cp','$sp','$img')") ;
	echo "<p allign=center>Data added successfully.</p>";
}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="index.html">Go back to home</a>
</body>
</html>
