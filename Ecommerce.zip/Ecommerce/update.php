<?php
include('db.php');
$result=mysqli_query($conn,"SELECT * FROM mounty");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
	<h1 style="color: blue;">Update Product:</h1>
	<style>
		body{
			font-family: cursive;
		}
		td{
			font-family: Times New Roman;
			font-size: 20px;
			padding: 20px;
			color: black;

		}
	</style>
</head>
<body>
	<table>
		<tr>
			<td>Product Id</td>
			<td>Product Name</td>
			<td>Description</td>
			<td>Cost Price</td>
			<td>Selling Price</td>
			<td>Product Image</td>
			<td>Action</td>

		</tr>
		<?php
		$i=0;
		while($row=mysqli_fetch_array($result))
		{
			if($i%2==0)
			
				$classname="even";
			else
				$classname="odd";
		
		?>
		<tr class="<?php if(isset($classname)) echo $classname;?>">
			<td><?php echo $row["pid"];?></td>
			<td><?php echo $row["title"];?></td>
			<td><?php echo $row["des"];?></td>
			<td><?php echo $row["cp"];?></td>
			<td><?php echo $row["sp"];?></td>
			<td> <img src="images/<?php echo $row["img"]; ?>"width='150' height='100' />
		</td>
			<td><a href="updateProcess.php?pid=<?php echo $row["pid"];?>">Update</a></td>
		</tr>
		<?php
		$i++;
	}
		?>
	</table>
<p><a href="crud.html" target="blank">Click here for other crud functionalities</a></p>
</body>
</html>