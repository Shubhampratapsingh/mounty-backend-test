<?php 
include 'database cnnct 25th.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	
		<style type="text/css">
		table{
			border: 1px solid red;
			height: 400px;
			width: 400px;
			border: 1px solid blue;
			box-shadow: 10px 10px green;
			padding-top: 10px;
			margin-top: 170px;
			margin-left: 500px;
			
		}
		td{
			color:black;
			font-weight: bold;

		}
		
		body{
			background: url('ecommerce.png') no-repeat;
			background-size: cover;
			
		}
	</style>
	
	
</head>
<body>
<form method="post" action="login2database 25th.php"><br>
		<tr><td>EmailId:
		<input type="text" name="email"><br></td></tr>
		<tr><td>Password:
		<input type="password" name="pwd"><br></td></tr>
		<tr><td><input type="submit" value="LOGIN" name="LOGIN"><br></td></tr>
		<tr><td>Dont have an account you can  <a href="Sign Up.php">Signup</a> here!!</td></tr>
	</table>
		
	</form>
	
	<?php
	
	$Email=$_POST['email'];
	$Pwd=$_POST['pwd'];
	$sql="SELECT * FROM logintable WHERE Email='$Email';";
	$result=mysqli_query($conn,$sql);
	$resultCheck=mysqli_num_rows($result);
	if($resultCheck < 1)
	{
		header("location:login2database 25th.php?error=user not registered");
	}
	else{
		header("location:login2database 25th.php?error=Successfully logged in");
	}
	?>
</body>
</html>