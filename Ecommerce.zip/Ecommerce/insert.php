<!DOCTYPE html>
<html>
<head>
	<style>
		body{
			font-family: Times New Roman;
			font-size: 20px;
			color: green;
			margin:30px;
			padding: 20px;
		}
	</style>
	<title>Ecommerce</title>
	<h1 style="color: blue;">Insert Product:</h1>
</head>
<body>
<form method="post" action="process.php">
	Title:<br/>
	<input type="text" name="title"/>
	<br/>
	Description:<br/>
	<input type="text" name="des"/>
	<br/>
	Cost Price:<br/>
	<input type="number" name="cp"/>
	<br/>
	Selling Price:<br/>
	<input type="number" name="sp"/>
	<br/>
	Upload Image:<br/>
	<input type="file" name="img" />
	<br/>
	<input type="submit" name="save" value="SUBMIT">
	<br/>
</form>
<p><a href="crud.html" target="blank">Click here for other crud functionalities</a></p>
</body>
</html>