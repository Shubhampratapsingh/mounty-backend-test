<!DOCTYPE html>
<html>
<head>
	<title>Ecommerce</title>
</head>
<body>
<form method="post" action="process.php">
	Title:<br/>
	<input type="text" name="title"/>
	<br/>
	Description:<br/>
	<input type="text" name="des"/>
	<br/>
	Cost Price:<br/>
	<input type="number" name="cp"/>
	<br/>
	Selling Price:<br/>
	<input type="number" name="sp"/>
	<br/>
	Upload Image:<br/>
	<input type="file" name="img" />
	<br/>
	<input type="submit" name="save" value="SUBMIT">
	<br/>
</form>
<p><a href="crud.html" target="blank">Click here for other crud functionalities</a></p>
</body>
</html>