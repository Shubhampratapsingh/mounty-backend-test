<?php 
include 'database cnnct 25th.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>

	<style type="text/css">
		table{
			border: 1px solid red;
			height: 400px;
			width: 400px;
			border: 1px solid blue;
			box-shadow: 10px 10px green;
			padding-top: 10px;
			margin-top: 170px;
			margin-left: 500px;
			/*transform: rotate(30deg);*/
		}
		td{
			color:black;
			font-weight: bold;

		}
		b{
			color: blue;
		}
		body{
			background: url('ecommerce.png') no-repeat;
			background-size: cover;
			
		}
	</style>
	<h1><u>Sign Up To Continue:</u></h1>
</head>
<body>
	<form action="signup db29.php" method="POST" id="signup">
	<table cellspacing="10px" cellpadding="10px">
		<tr>
			
			<td><?php if(isset($_GET['error'])) 
		echo "<span style='color:red'>".$_GET['error']."</span><br>"; 
		?>User-Name:<input type="text" name="user" id="user" value="<?php if(isset($_POST['user'])) echo $_POST['user']?>"></td>
		</tr>
		<tr>
			<td>Set-Password:<input type="password" name="pwd" id="password" value="<?php if(isset($_POST['pwd'])) echo $_POST['pwd']?>"></td>
		</tr>
		<tr>
			<td>
				Confirm Password:<input type="password" name="cpwd" id="Confirm" >
			</td>
		</tr>
		<tr>
			<td>Recovery-Email:<input type="text" name="Email" value="<?php if(isset($_POST['Email'])) echo $_POST['Email']?>"></td>
		</tr>
		
		<tr>
			<td>
				Phone No.:<input type="text" name="phone" value="<?php if(isset($_POST['phone'])) echo $_POST['phone']?>">
			</td>
		</tr>
		<tr>
			<td><input type="submit" name="submit"></td>
		</tr>
		<tr><td>Already have an account you can <a href="login2database 25th.php">login</a> here!!</td></tr>
	</table>
		
	</form>
			
			

</body>
</html>