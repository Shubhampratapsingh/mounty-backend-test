<?php
$server='localhost';
$user='shubham';
$pass='shubham';
$db='mounty';
$conn=mysqli_connect($server,$user,$pass,$db);
if(!$conn)
{
	die('Could not connect to database'.mysql_error());
}

?>